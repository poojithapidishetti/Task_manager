document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('taskForm');
  const titleInput = document.getElementById('title');
  const descInput = document.getElementById('description');
  const dateInput = document.getElementById('dueDate');
  const taskTable = document.getElementById('taskTableBody');

  // Load tasks on page load
  const loadTasks = async () => {
    const res = await fetch('/api/tasks');
    const tasks = await res.json();
    taskTable.innerHTML = '';
    tasks.forEach(addTaskToTable);
  };

  // Add task to table
  function addTaskToTable(task) {
    const tr = document.createElement('tr');

    tr.innerHTML = `
      <td>${task.title}</td>
      <td>${task.description || '-'}</td>
      <td>${task.dueDate ? new Date(task.dueDate).toLocaleDateString() : '-'}</td>
      <td>
        <span class="badge ${task.completed ? 'bg-success' : 'bg-secondary'}">
          ${task.completed ? 'Completed' : 'Pending'}
        </span>
      </td>
      <td>
        <button class="btn btn-sm btn-warning me-1" onclick="toggleStatus('${task._id}')">
          Toggle
        </button>
        <button class="btn btn-sm btn-danger" onclick="deleteTask('${task._id}')">
          Delete
        </button>
      </td>
    `;

    taskTable.appendChild(tr);
  }

  // Submit new task
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const title = titleInput.value.trim();
    const description = descInput.value.trim();
    const dueDate = dateInput.value;

    if (!title) return alert('Title is required.');

    const res = await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, description, dueDate })
    });

    const newTask = await res.json();
    addTaskToTable(newTask);
    form.reset();
  });

  // Make toggle and delete globally accessible
  window.toggleStatus = async (id) => {
    const res = await fetch(`/api/tasks/${id}`, { method: 'PATCH' });
    const updated = await res.json();
    loadTasks(); // reload list
  };

  window.deleteTask = async (id) => {
    await fetch(`/api/tasks/${id}`, { method: 'DELETE' });
    loadTasks(); // reload list
  };

  loadTasks();
});
